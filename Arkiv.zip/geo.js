var userLocation = "";

$(document).ready(function(){
  navigator.geolocation.getCurrentPosition(foundLocation, noLocation);

  function foundLocation(position) {
    var lat = position.coords.latitude;
    var lon = position.coords.longitude;
    userLocation = lat + ' ' + lon;
  }
  
  function noLocation() {
    console.log("no geo hereee");
  }
})
